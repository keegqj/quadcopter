#ifndef _MOTOR_H
#define _MOTOR_H


void Motor_Init(void);
void Motor_Run(int speed);
void MotorInit_Handle(void);
void MovementHandle(void);




#endif

